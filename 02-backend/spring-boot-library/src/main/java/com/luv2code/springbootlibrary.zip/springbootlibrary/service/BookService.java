package com.luv2code.springbootlibrary.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springbootlibrary.dao.BookRepository;
import com.luv2code.springbootlibrary.dao.CheckoutRepository;
import com.luv2code.springbootlibrary.entity.Book;
import com.luv2code.springbootlibrary.entity.Checkout;

@Service
@Transactional 

public class BookService {
//we are adding book repo and checkout repo
	private BookRepository bookRepository;
	
	private CheckoutRepository checkoutRepository;
	
	//constructor with two param, using constructor dependency injection to setup our repos
	public BookService(BookRepository bookRepository, CheckoutRepository checkoutRepository) {
		
		this.bookRepository = bookRepository;
		this.checkoutRepository = checkoutRepository;
		
	}//using this service we can use these repos
	//first function isndie our service
	//creating a function that returns a book and throws a exception
	
	public Book checkoutBook(String userEmail, Long bookId) throws Exception{
		
		//optional book that we are getting from out data base, based on the bookId
		Optional<Book> book = bookRepository.findById(bookId);
		
		//call the db by findByUserEmailAndBookId where we pass in email and bookID
		Checkout validateCheckout = checkoutRepository.findByUserEmailAndBookId(userEmail, bookId);
		
		//validating 
		if(!book.isPresent() || validateCheckout != null || book.get().getCopiesAvailable() <= 0) {
			throw new Exception("Book doesnot exist or its been already checked out by the user");
		}
		
		//set the copies availbe minus 1
		book.get().setCopiesAvailable(book.get().getCopiesAvailable() -1);
		bookRepository.save(book.get());
		
		//create a new checkout record and save that into db
		Checkout checkout = new Checkout(
				userEmail,
				LocalDate.now().toString(),
				LocalDate.now().plusDays(7).toString(),
				book.get().getId()
				
				);
		
		//return the book
		checkoutRepository.save(checkout);
		return book.get();
			
	}
	public Boolean checkoutBookByUser(String userEmail, Long bookId) {
		
		Checkout validateCheckout = checkoutRepository.findByUserEmailAndBookId(userEmail, bookId);
		if(validateCheckout != null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int currentLoansCount(String userEmail) {
		return checkoutRepository.findBooksByUserEmail(userEmail).size();
		
	}
	
}
















